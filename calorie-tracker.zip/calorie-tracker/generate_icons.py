#!/usr/bin/env python3
"""Generate simple PWA icons for Calx app."""
import os, struct, zlib

def make_png(size, color1=(74,222,128), color2=(34,211,238)):
    """Create a minimal PNG icon programmatically."""
    import math
    
    def pack_chunk(chunk_type, data):
        c = chunk_type + data
        return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)
    
    w = h = size
    # Create RGBA pixel data
    pixels = []
    cx, cy = w/2, h/2
    
    for y in range(h):
        row = []
        for x in range(w):
            dx, dy = x - cx, y - cy
            dist = math.sqrt(dx*dx + dy*dy)
            r_outer = w * 0.47
            r_inner = w * 0.38
            
            # Background circle
            if dist <= r_outer:
                # Gradient blend
                t = (x + y) / (w + h)
                r = int(color1[0] * (1-t) + color2[0] * t)
                g = int(color1[1] * (1-t) + color2[1] * t)
                b = int(color1[2] * (1-t) + color2[2] * t)
                # Dark center
                if dist <= r_inner:
                    r = int(r * 0.15 + 10)
                    g = int(g * 0.15 + 10)
                    b = int(b * 0.15 + 15)
                row.extend([r, g, b, 255])
            else:
                row.extend([0, 0, 0, 0])  # transparent
        pixels.append(bytes(row))
    
    # PNG signature
    sig = b'\x89PNG\r\n\x1a\n'
    # IHDR
    ihdr = struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)  # RGB but we use RGBA
    ihdr = struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)  # RGBA
    
    # IDAT
    raw = b''
    for row in pixels:
        raw += b'\x00' + row  # filter byte
    
    compressed = zlib.compress(raw, 9)
    
    png = sig
    png += pack_chunk(b'IHDR', ihdr)
    png += pack_chunk(b'IDAT', compressed)
    png += pack_chunk(b'IEND', b'')
    return png

os.makedirs('icons', exist_ok=True)
for size in [152, 167, 180, 192, 512]:
    data = make_png(size)
    path = f'icons/icon-{size}.png'
    with open(path, 'wb') as f:
        f.write(data)
    print(f'Created {path} ({len(data)} bytes)')
print('All icons created!')
